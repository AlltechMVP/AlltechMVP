
const SUPABASE_URL = "https://bpxvixyogbvvhykfeyqj.supabase.co";
const SUPABASE_ANON_KEY = "YOUR_ANON_KEY_HERE"; // Replace this with your actual key
const supabase = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
